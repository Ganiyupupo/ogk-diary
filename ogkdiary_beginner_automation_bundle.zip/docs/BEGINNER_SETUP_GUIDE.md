# Beginner setup

1. Create accounts: Make, Railway, Runway, Telegram, Google Drive, Metricool.
2. In Google Drive create:
   - ogkdiary/videos
   - ogkdiary/tiktok_ready
   - ogkdiary/analytics
3. Upload pretrain/weekly_optimization_seed.json to ogkdiary/analytics and rename it to weekly_optimization.json.
4. Upload the spreadsheet template to Google Drive and open it with Google Sheets.
5. Upload the 3 files inside railway_render_service/ to Railway:
   - renderer_service.py
   - Dockerfile
   - requirements.txt
6. In Railway add env var:
   RENDER_SERVICE_API_KEY=your_secret_here
7. Deploy Railway and open:
   https://YOUR-RAILWAY-APP/health
   It must show {"status":"ok"}.
8. In Telegram open @BotFather, send /newbot, create the bot, copy the bot token, then send your bot a message.
9. Get your chat id by opening:
   https://api.telegram.org/botYOUR_BOT_TOKEN/getUpdates
   and copy the chat id number.
10. In Runway create an API key and save it.
11. In Make build Scenario A in this order:
   Scheduler
   Set multiple variables
   Google Drive search file
   Google Drive download file
   JSON parse optimizer file
   Iterator over slot_plan
   Router (day/series)
   OpenAI script
   JSON parse script
   OpenAI scene plan
   JSON parse scenes
   Iterator over scenes
   HTTP POST Runway create task
   Sleep
   HTTP GET Runway task status
   Router for status
   Array aggregator
   HTTP POST Railway /render
   JSON parse render response
   HTTP get final file
   Google Drive upload
   Telegram send video
   Google Sheets add row
12. In the Railway render request set:
   handle_watermark = @ogkdiary
   handle_position = bottom_right
13. Test in order:
   script JSON
   scene JSON
   Runway clip generation
   Railway render
   Drive upload
   Telegram send
   Sheets row
